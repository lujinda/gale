#/usr/bin/env python
#coding:utf-8
# Author        : tuxpy
# Email         : q8886888@qq.com.com
# Last modified : 2015-05-02 12:18:07
# Filename      : version.py
# Description   : 
import sys
is_py3 = sys.version[0] == '3'

