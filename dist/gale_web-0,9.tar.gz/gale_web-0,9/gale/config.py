#!/usr/bin/env python
#coding:utf8
# Author          : tuxpy
# Email           : q8886888@qq.com
# Last modified   : 2015-03-25 14:01:15
# Filename        : gale/config.py
# Description     : 
from __future__ import unicode_literals, print_function

CRLF = b"\r\n"

