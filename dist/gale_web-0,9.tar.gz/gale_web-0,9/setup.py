#/usr/bin/env python
#coding:utf-8
# Author        : tuxpy
# Email         : q8886888@qq.com.com
# Last modified : 2015-06-09 10:04:55
# Filename      : setup.py
# Description   : 
from distutils.core import setup
setup(
        name = 'gale_web',
        version = '0,9',
        author = 'tuxpy',
        packages = [
            'gale',
            'gale.wsgi',
            ],
        description = 'a web framework like tornado',
        )


